<?php
/*
* Copyright 2007-2013 Charles du Jeu - Abstrium SAS <team (at) pyd.io>
* This file is part of Pydio.
*
* Pydio is free software: you can redistribute it and/or modify
* it under the terms of the GNU Affero General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Pydio is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Affero General Public License for more details.
*
* You should have received a copy of the GNU Affero General Public License
* along with Pydio.  If not, see <http://www.gnu.org/licenses/>.
*
* The latest code can be found at <http://pyd.io/>.
*/
$mess=array(
"Skeleton Plugin" => "Plugin Esqueleto",
"This is an empty container to demonstrate the basics of plugins coding." => "Isto é um armazenamento vazio para demonstrar os básicos de escrever um plugin.",
"Custom Footer" => "Barra Inferior Personalizada",
"Show a custom footer div" => "Mostrar uma barra inferior personalizada",
"Footer Content" => "Conteúdo da barra Inferior",
"Display this content in the footer" => "Mostrar este conteúdo na barra inferior",
"Button Target Url" => "URL alvo do botão",
"The target URL of the button that will be added to the application" => "URL alvo do botão que será adicionado à aplicação",
);
