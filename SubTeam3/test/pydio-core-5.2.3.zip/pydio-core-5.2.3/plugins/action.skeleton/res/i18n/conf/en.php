<?php
/*
* Copyright 2007-2013 Charles du Jeu - Abstrium SAS <team (at) pyd.io>
* This file is part of Pydio.
*
* Pydio is free software: you can redistribute it and/or modify
* it under the terms of the GNU Affero General Public License as published by
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
*
* Pydio is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU Affero General Public License for more details.
*
* You should have received a copy of the GNU Affero General Public License
* along with Pydio.  If not, see <http://www.gnu.org/licenses/>.
*
* The latest code can be found at <http://pyd.io/>.
*/
$mess=array(
"Skeleton Plugin" => "Skeleton Plugin",
"This is an empty container to demonstrate the basics of plugins coding." => "This is an empty container to demonstrate the basics of plugins coding.",
"Custom Footer" => "Custom Footer",
"Show a custom footer div" => "Show a custom footer div",
"Footer Content" => "Footer Content",
"Display this content in the footer" => "Display this content in the footer",
"Button Target Url" => "Button Target Url",
"The target URL of the button that will be added to the application" => "The target URL of the button that will be added to the application",
);
